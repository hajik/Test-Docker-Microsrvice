package main

import(
	"01-test-microservices-go-docker/repository"
	"01-test-microservices-go-docker/models"
	"01-test-microservices-go-docker/handlers"
	"net/http"
	"log"
)

func main(){

	repository.AddProduct(models.Product{
		Name: "Milk",
		UnitPrice: 4.00,
	})

	repository.AddProduct(models.Product{
		Name: "Bread",
		UnitPrice: 5.00,
	}) 

	http.HandleFunc("/", handlers.HandleRequest)

	
	err := http.ListenAndServe(":8080", nil)
	if err != nil {
		log.Println(err)
		return
	}
		
	log.Println("Port :8080")	

}